﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using totalizarPalavras.Methods;
using totalizarPalavras.Models;

namespace totalizarPalavras.Controllers
{
    public class HomeController : Controller
    {
        #region instâncias globais
        FeedTopicMethods feedTopicMethods = new FeedTopicMethods();
        FilesManagementMethdos filesManagementMethdos = new FilesManagementMethdos();
        #endregion

        public ActionResult Index()
        {
            int xMLDocumentReader_topicNumbersLimit = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["XMLDocumentReader_topicNumbersLimit"]); // limite de tópicos (post) lidos

            // obter o conteúdo de um arquivo xml                      
            var fullTextXml = filesManagementMethdos.XMLDocumentReader();

            // criar uma lista (linha a linha) com os tópicos (com os totais de palavras e desconsiderando as tags, pronomes, artigos e caracteres especiais)
            List<FeedTopicLine> feedTopicLines = feedTopicMethods.XMLSplitTextToCreateFeedTopicLineList(fullTextXml, xMLDocumentReader_topicNumbersLimit);

            // criar a lista sintética dos tópicos
            List<FeedTopic> feedTopics = feedTopicMethods.CreateFeedTopicList(feedTopicLines, fullTextXml, xMLDocumentReader_topicNumbersLimit);

            // criar o ranking com as palavras mais citadas
            List<TopWordsRanking> rankingTopWords = feedTopicMethods.RankingTopWords(feedTopics);

            ViewBag.Ranking = rankingTopWords.OrderByDescending(x=>x.WordsCount);

            return View(feedTopics);
        }

        public PartialViewResult _RankingTopWordsView(IEnumerable<TopWordsRanking> ranking)
        {           
            return PartialView(ranking);
        }

        public PartialViewResult _FeedTopicWordsCountView(IEnumerable<FeedTopic> feedTopics)
        {
            return PartialView(feedTopics);
        }
    }
}