﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;

namespace totalizarPalavras.Methods
{
    public class FilesManagementMethdos
    {
        #region lista de variáveis globais
        // opções: 1)local 2)web - esse flag identifica se o xml será local ou web
        string pathFile = System.Configuration.ConfigurationManager.AppSettings["XMLDocumentReader_localORweb"] == "local" ?
                            HttpContext.Current.Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["XMLDocumentReader_path"]) :
                            System.Configuration.ConfigurationManager.AppSettings["XMLDocumentReader_uri"];
        #endregion

        /// <summary>
        /// ler arquivos xml
        /// </summary>        
        /// <returns>obj xml com o arquivo lido</returns>
        public XmlNodeList XMLDocumentReader()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(pathFile);

            //Pegando elemento pelo nome da TAG            
            var xmlNodeList = xmlDocument.GetElementsByTagName(System.Configuration.ConfigurationManager.AppSettings["XMLDocumentReader_tagParentNameToFilter"]);

            return xmlNodeList;
        }
    }
}