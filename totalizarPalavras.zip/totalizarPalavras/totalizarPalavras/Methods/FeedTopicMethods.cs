﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using totalizarPalavras.Models;

namespace totalizarPalavras.Methods
{
    public class FeedTopicMethods
    {
        #region lista de variávies globais
        // lista de tags complexas (aquelas que terão todo o texto excluído de dentro de seus limites)
        string[] complexTags_beginArray = (assets.SiteConfigure.ComplexTags_begin).Split(',').ToArray();
        string[] complexTags_endArray = (assets.SiteConfigure.ComplexTags_end).Split(',').ToArray();

        // lista de palavras e caracteres bloqueados
        string[] charactersBlockedArray = (assets.SiteConfigure.ListHtmlTags + " " + assets.SiteConfigure.ListSpecialCharacters).Split(' ').ToArray();              
        string[] wordsBlockedArray = System.Configuration.ConfigurationManager.AppSettings["BlockedWordList"].Split(' ').ToArray();

        // marca de fim do parágrafo (usado para definir entre os parágrafos)
        string paragraphEndMark = assets.SiteConfigure.ParagraphEndMark;
        #endregion

        #region métodos para preparação do xml feed
        /// <summary>
        /// criar a lista sintética dos tópicos 
        /// </summary>
        /// <param name="xmlNodeTextArrayItem"></param>
        /// <param name="wordsBlockedArray"></param>
        /// <returns>lista de FeedTopic</returns>
        public List<FeedTopic> CreateFeedTopicList(List<FeedTopicLine> feedTopicLineList, XmlNodeList fullTextXml, int xMLDocumentReader_topicNumbersLimit)
        {
            List<FeedTopic> FeedTopic = new List<Models.FeedTopic>();

            int topicCount = 0;

            foreach (XmlNode xmlNode in fullTextXml)
            {
                string title = xmlNode["title"].InnerText;                
                string link = !string.IsNullOrEmpty(xmlNode["link"].InnerText) ? xmlNode["link"].InnerText : "";

                if (!string.IsNullOrEmpty(xmlNode["link"].InnerText))
                    link = System.Configuration.ConfigurationManager.AppSettings["UriMasterFeedRss"] + FeedPostLinkCleaner(xmlNode["link"].InnerText);

                var feedTopicLineTemp = feedTopicLineList.Where(x => x.FeedTopicId == topicCount).ToList();
                int linesCount = feedTopicLineTemp.Count();
                int wordsCount = feedTopicLineTemp.Sum(x => x.WordsCount);

                FeedTopic FeedTopicTemp = new FeedTopic()
                {
                    FeedTopicId = topicCount + 1,
                    FeedTopicTitle = title,
                    WordsCount = wordsCount,
                    LinesCount = linesCount,
                    Link = link,
                    FeedTopicLines = feedTopicLineTemp
                };

                FeedTopic.Add(FeedTopicTemp);
                topicCount++;
            }

            return FeedTopic.Take(10).ToList();
        }

        /// <summary>
        /// sumariza as informações da lista FeedTopic para criar o ranking topTen
        /// </summary>
        /// <param name="feedTopics"></param>
        /// <returns></returns>
        public List<TopWordsRanking> RankingTopWords(List<FeedTopic> feedTopics)
        {
            string topicLines = "";

            foreach (var topic in feedTopics)
            {
                foreach (var lines in topic.FeedTopicLines)
                {
                    topicLines += " " + lines.Text.TrimEnd();
                }
            }

            var textTopicLinesArray = topicLines.Split(' ').ToList();

            var resultado =
                from p in textTopicLinesArray
                group p by p into g
                orderby g.Count() descending
                select new { palavra = g.Key, contador = g.Count() };

            List<TopWordsRanking> topWordsRankingList = new List<TopWordsRanking>();

            foreach (var item in resultado)
            {
                TopWordsRanking topWordsRankingTemp = new TopWordsRanking()
                {
                    Word = item.palavra,
                    WordsCount = item.contador
                };

                topWordsRankingList.Add(topWordsRankingTemp);
            }

            return topWordsRankingList.Take(Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["RankingTopWords_limit"])).ToList();
        }

        /// <summary>
        /// ler o xml para criar a lista FeedTopicLine, onde cada parágrafo do xml será armazenado em uma linha da lista        
        /// </summary>
        /// <param name="xmlTextToSplitArray">texto fonte em xml</param>
        /// <returns>lista FeedTopicLine desconsiderando as tags, pronomes, artigos e caracteres especiais e com totais de palavras </returns>
        public List<FeedTopicLine> XMLSplitTextToCreateFeedTopicLineList(XmlNodeList xmlTextToSplitArray, int xMLDocumentReader_topicNumbersLimit)
        {
            List<FeedTopicLine> feedTopicLines = new List<Models.FeedTopicLine>();

            int feedTopicId = 0;

            foreach (XmlNode xmlNode in xmlTextToSplitArray)
            {
                string xmlNodeText = xmlNode[System.Configuration.ConfigurationManager.AppSettings["XMLDocumentReader_tagNameToFilter"]].InnerText.ToLower().Trim();
                int textPointToBeginRead = 0;

                int feedTopicLineId = 0;
                while (!string.IsNullOrEmpty(xmlNodeText))
                {
                    textPointToBeginRead = xmlNodeText.IndexOf(assets.SiteConfigure.TextPointToBeginRead);
                    if (textPointToBeginRead > 0)
                    {
                        string line = xmlNodeText.Substring(0, textPointToBeginRead + 4);
                        string oldLine = xmlNodeText.Substring(0, textPointToBeginRead + 4);

                        if (line.Contains(paragraphEndMark))
                            break;

                        else if (!line.Contains(paragraphEndMark)) // pular as linhas do fim do tópico                                 
                        {
                            string newNodeText = XmlTextCleaner(line, charactersBlockedArray, wordsBlockedArray);
                            string[] newNodeTextArray = newNodeText.Split(' ').ToArray();
                            int newNodeTextNumCharacters = newNodeText.Length;

                            FeedTopicLine feedTopicLine = new FeedTopicLine()
                            {
                                FeedTopicLineId = feedTopicLineId,
                                FeedTopicId = feedTopicId,
                                Text = newNodeText,
                                WordsCount = newNodeTextArray.Count()
                            };

                            feedTopicLines.Add(feedTopicLine);
                            feedTopicLineId++;
                        }

                        xmlNodeText = xmlNodeText.Replace(oldLine, "").Trim();
                    }
                }
                feedTopicId++;
            }

            return feedTopicLines;
        }
        #endregion

        #region métodos auxiliares
        /// <summary>
        /// eliminar do texto as tags, pronomes, artigos e caracteres especiais
        /// </summary>
        /// <param name="xmlNodeFullText">texto xml</param>
        /// <param name="charactersBlockedArray">relçao de caracteres especiais e tegs a ser excluída do texto</param>
        /// <param name="wordsBlockedArray">relçao de artigos e pronomes a ser excluída do texto</param>
        /// <returns>texto "limpo"</returns>
        private string XmlTextCleaner(string xmlNodeFullText, string[] charactersBlockedArray, string[] wordsBlockedArray)
        {
            xmlNodeFullText = xmlNodeFullText.Replace('"', ' ');
            string xmlNodeRepairText = ComplexTagsRemove(xmlNodeFullText); // remover as tags "<a href", "<iframe" e "<img"

            var textArray = xmlNodeRepairText.Split(' ').ToArray();
            string finalText = "";

            foreach (var item in textArray)
            {
                string newText = CharactersBlockedRemove(item, charactersBlockedArray); // remover os caracteres bloqueados

                if (!string.IsNullOrEmpty(newText.Trim()))
                    newText = WordsBlockedRemove(newText.Trim(), wordsBlockedArray); // remover as palavras bloqueados

                if (!string.IsNullOrEmpty(newText))
                    (finalText += " " + newText).Trim();
            }

            return finalText.Trim();
        }

        /// <summary>
        /// ler a lista das tags complexas (a href, iframe, img...), aquelas que terão todo o conteúdo entre os seus limites removido e invoca método onde esse texto será efetivamente eliminado (no "ComplexTagsRemoveProcess")
        /// </summary>
        /// <param name="xmlNodeText">texto xml</param>
        /// <returns>texto sem as tags complexas</returns>
        private string ComplexTagsRemove(string xmlNodeText)
        {           
            for (int i = 0; i < complexTags_beginArray.Count(); i++)
            {
                xmlNodeText = ComplexTagsRemoveProcess(xmlNodeText, complexTags_beginArray[i], complexTags_endArray[i]);
            }

            return xmlNodeText;
        }

        /// <summary>
        /// eliminar as tags complexas (a href, iframe, img...), aquelas que terão todo o conteúdo entre os seus limites removido
        /// </summary>
        /// <param name="xmlNodeText">texto xml</param>
        /// <param name="beginTag">início da tag</param>
        /// <param name="endTag">final da tag</param>
        /// <returns>texto sem as tags complexas</returns>
        private string ComplexTagsRemoveProcess(string xmlNodeText, string beginTag, string endTag)
        {
            while (xmlNodeText.Contains(beginTag))
            {
                int beginPosition = xmlNodeText.IndexOf(beginTag);
                int endPosition = xmlNodeText.IndexOf(endTag);

                string substrToClear = "";

                if (endPosition > beginPosition)
                {
                    for (int i = beginPosition; i < endPosition + 2; i++)
                        substrToClear += xmlNodeText[i].ToString();

                    if (!string.IsNullOrEmpty(substrToClear))
                        xmlNodeText = xmlNodeText.Replace(substrToClear, "");
                }
            }

            return xmlNodeText;
        }

        /// <summary>
        /// remover os carecteres especiais do texto
        /// </summary>
        /// <param name="xmlNodeTextArrayItem">array com o texto sem a tag "a href"</param>
        /// <param name="charactersBlockedArray">array com as tags e caracteres bloqueados</param>
        /// <returns>texto sem os os carecteres especiais</returns>
        private string CharactersBlockedRemove(string xmlNodeTextArrayItem, string[] charactersBlockedArray)
        {
            foreach (var characterItem in charactersBlockedArray)
                while (xmlNodeTextArrayItem.Contains(characterItem) && !string.IsNullOrEmpty(xmlNodeTextArrayItem) && !string.IsNullOrEmpty(characterItem))
                    xmlNodeTextArrayItem = xmlNodeTextArrayItem.Replace(characterItem, "");

            return xmlNodeTextArrayItem;
        }

        /// <summary>
        /// remover as palavras bloquedas do texto
        /// </summary>
        /// <param name="xmlNodeTextArrayItem">array com o texto sem a tag "a href"</param>
        /// <param name="wordsBlockedArray">array com as palavras bloqueadas</param>
        /// <returns>texto sem as palavras bloqueadas</returns>
        private string WordsBlockedRemove(string xmlNodeTextArrayItem, string[] wordsBlockedArray)
        {
            foreach (var characterItem in wordsBlockedArray)
                if (xmlNodeTextArrayItem.Trim() == characterItem)
                    xmlNodeTextArrayItem = "";

            return xmlNodeTextArrayItem;
        }

        /// <summary>
        /// retornar uri do post
        /// </summary>
        /// <param name="link">uri completa do post</param>
        /// <returns>uri</returns>
        public string FeedPostLinkCleaner(string link)
        {
            int linkLenght = link.Length;
            string newLink = "";
            int endPosition = 0;

            for (int i = linkLenght - 1; i > 0; i--)
            {
                char charTemp = link[i];

                if (charTemp == '/')
                    endPosition++;

                if (endPosition > 1) // encontrou a segunda '/' da direita para esquerda
                    break;

                newLink += charTemp.ToString();
            }

            int newLinkLenght = newLink.Length;
            string linkFixed = "";

            for (int i = newLinkLenght - 1; i > 0; i--)
            {
                linkFixed += newLink[i].ToString();
            }

            return linkFixed;
        }
        #endregion
    }
}