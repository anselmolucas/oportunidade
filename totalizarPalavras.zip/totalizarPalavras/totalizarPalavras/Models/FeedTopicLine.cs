﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace totalizarPalavras.Models
{
    public class FeedTopicLine
    {
        public int FeedTopicLineId { get; set; }
        public int FeedTopicId { get; set; }
        public string Text { get; set; }
        public int WordsCount { get; set; }
    }
}