﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace totalizarPalavras.Models
{
    public class TopWordsRanking
    {
        public int WordsCount { get; set; }
        public string Word { get; set; }
    }
}